from setuptools import setup, find_packages
setup(
    name='pymatrixcalc',
    version='0.1',
    description='get all of the functions for calculating matrixes',
    py_modules=["MatrixCalc"],
    packages=find_packages()
)